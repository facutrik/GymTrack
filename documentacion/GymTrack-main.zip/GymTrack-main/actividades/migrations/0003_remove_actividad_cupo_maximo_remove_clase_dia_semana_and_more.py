from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):
    dependencies = [
        ('actividades', '0002_initial'),
    ]
    operations = [
        migrations.RemoveField(
            model_name='actividad',
            name='cupo_maximo',
        ),
        migrations.RemoveField(
            model_name='clase',
            name='dia_semana',
        ),
        migrations.RemoveField(
            model_name='clase',
            name='entrenador',
        ),
        migrations.RemoveField(
            model_name='clase',
            name='hora_fin',
        ),
        migrations.RemoveField(
            model_name='clase',
            name='hora_inicio',
        ),
        migrations.AddField(
            model_name='actividad',
            name='activa',
            field=models.BooleanField(default=True),
        ),
        migrations.AddField(
            model_name='actividad',
            name='requiere_reserva',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='clase',
            name='cupo_maximo',
            field=models.PositiveIntegerField(default=20),
        ),
        migrations.AddField(
            model_name='clase',
            name='nombre',
            field=models.CharField(blank=True, max_length=100, null=True),
        ),
        migrations.AlterField(
            model_name='actividad',
            name='descripcion',
            field=models.TextField(blank=True, null=True),
        ),
        migrations.AlterField(
            model_name='clase',
            name='actividad',
            field=models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='clases', to='actividades.actividad'),
        ),
    ]
